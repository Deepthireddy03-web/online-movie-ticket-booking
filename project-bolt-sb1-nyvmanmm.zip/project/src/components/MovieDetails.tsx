import React, { useState } from 'react';
import { ArrowLeft, Star, Clock, Calendar, Users, MapPin, Play } from 'lucide-react';
import { Movie, ShowTime } from '../types';

interface MovieDetailsProps {
  movie: Movie;
  showTimes: ShowTime[];
  onBack: () => void;
  onBookTickets: (showTime: ShowTime) => void;
}

const MovieDetails: React.FC<MovieDetailsProps> = ({ movie, showTimes, onBack, onBookTickets }) => {
  const [selectedDate, setSelectedDate] = useState('2024-01-15');

  const filteredShowTimes = showTimes.filter(st => st.movieId === movie.id && st.date === selectedDate);
  
  const dates = ['2024-01-15', '2024-01-16', '2024-01-17', '2024-01-18'];
  
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return {
      day: date.toLocaleDateString('en-US', { weekday: 'short' }),
      date: date.getDate(),
      month: date.toLocaleDateString('en-US', { month: 'short' })
    };
  };

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Hero Section */}
      <div className="relative h-96 md:h-[500px] overflow-hidden">
        <img
          src={movie.backdrop}
          alt={movie.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/70 to-transparent" />
        
        <button
          onClick={onBack}
          className="absolute top-6 left-6 bg-black bg-opacity-50 text-white p-3 rounded-full hover:bg-opacity-70 transition-all"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>

        <div className="absolute bottom-8 left-8 right-8">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">{movie.title}</h1>
          <div className="flex items-center space-x-6 text-white/90 mb-4">
            <div className="flex items-center space-x-2">
              <Star className="w-5 h-5 text-yellow-500 fill-current" />
              <span className="font-bold">{movie.rating}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5" />
              <span>{movie.duration} min</span>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="w-5 h-5" />
              <span>{new Date(movie.releaseDate).getFullYear()}</span>
            </div>
            <span className="bg-yellow-500 text-black px-2 py-1 rounded text-sm font-bold">
              {movie.certificate}
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {movie.genre.map((genre) => (
              <span
                key={genre}
                className="px-3 py-1 bg-white/20 backdrop-blur-sm text-white text-sm rounded-full"
              >
                {genre}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Movie Info */}
          <div className="lg:col-span-2">
            <div className="bg-gray-800 rounded-xl p-6 mb-6">
              <h2 className="text-2xl font-bold text-white mb-4">About the Movie</h2>
              <p className="text-gray-300 leading-relaxed mb-6">{movie.description}</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">Director</h3>
                  <p className="text-gray-300">{movie.director}</p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">Language</h3>
                  <p className="text-gray-300">{movie.language}</p>
                </div>
                <div className="md:col-span-2">
                  <h3 className="text-lg font-semibold text-white mb-2">Cast</h3>
                  <p className="text-gray-300">{movie.cast.join(', ')}</p>
                </div>
              </div>
            </div>

            {/* Showtimes */}
            <div className="bg-gray-800 rounded-xl p-6">
              <h2 className="text-2xl font-bold text-white mb-6">Select Showtime</h2>
              
              {/* Date Selection */}
              <div className="flex space-x-4 mb-6 overflow-x-auto pb-2">
                {dates.map((date) => {
                  const formatted = formatDate(date);
                  return (
                    <button
                      key={date}
                      onClick={() => setSelectedDate(date)}
                      className={`flex-shrink-0 text-center p-3 rounded-lg transition-all ${
                        selectedDate === date
                          ? 'bg-red-600 text-white'
                          : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                      }`}
                    >
                      <div className="text-sm">{formatted.day}</div>
                      <div className="text-lg font-bold">{formatted.date}</div>
                      <div className="text-xs">{formatted.month}</div>
                    </button>
                  );
                })}
              </div>

              {/* Showtimes */}
              <div className="space-y-4">
                {filteredShowTimes.map((showTime) => (
                  <div key={showTime.id} className="bg-gray-700 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <MapPin className="w-5 h-5 text-gray-400" />
                        <div>
                          <h4 className="text-white font-medium">{showTime.theater}</h4>
                          <p className="text-gray-400 text-sm">{showTime.screen}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center space-x-2 text-green-400">
                          <Users className="w-4 h-4" />
                          <span className="text-sm">{showTime.availableSeats} seats available</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="text-2xl font-bold text-white">{showTime.time}</div>
                      <button
                        onClick={() => onBookTickets(showTime)}
                        className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
                      >
                        Book Now
                      </button>
                    </div>
                    
                    <div className="flex space-x-4 mt-3 text-sm text-gray-400">
                      <span>Premium: ${showTime.prices.premium}</span>
                      <span>Standard: ${showTime.prices.standard}</span>
                      <span>Economy: ${showTime.prices.economy}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-gray-800 rounded-xl p-6 sticky top-24">
              <img
                src={movie.poster}
                alt={movie.title}
                className="w-full rounded-lg mb-4"
              />
              <button className="w-full bg-white text-gray-900 font-medium py-3 rounded-lg mb-4 flex items-center justify-center space-x-2 hover:bg-gray-100 transition-colors">
                <Play className="w-5 h-5" />
                <span>Watch Trailer</span>
              </button>
              
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Release Date</span>
                  <span className="text-white">{new Date(movie.releaseDate).toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Duration</span>
                  <span className="text-white">{movie.duration} minutes</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Language</span>
                  <span className="text-white">{movie.language}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Certificate</span>
                  <span className="text-white">{movie.certificate}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieDetails;