import React, { useState, useEffect } from 'react';
import { ArrowLeft, Users, DollarSign } from 'lucide-react';
import { Movie, ShowTime, Seat } from '../types';

interface SeatSelectionProps {
  movie: Movie;
  showTime: ShowTime;
  onBack: () => void;
  onProceed: (selectedSeats: Seat[], totalAmount: number) => void;
}

const SeatSelection: React.FC<SeatSelectionProps> = ({ movie, showTime, onBack, onProceed }) => {
  const [seats, setSeats] = useState<Seat[]>([]);
  const [selectedSeats, setSelectedSeats] = useState<Seat[]>([]);

  useEffect(() => {
    // Generate seat layout
    const seatLayout: Seat[] = [];
    const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
    
    rows.forEach((row, rowIndex) => {
      let seatsPerRow = 12;
      let seatType: 'premium' | 'standard' | 'economy' = 'economy';
      
      if (rowIndex >= 7) seatType = 'premium';
      else if (rowIndex >= 3) seatType = 'standard';
      
      for (let i = 1; i <= seatsPerRow; i++) {
        seatLayout.push({
          id: `${row}${i}`,
          row,
          number: i,
          type: seatType,
          isBooked: Math.random() < 0.3, // 30% chance of being booked
          isSelected: false
        });
      }
    });
    
    setSeats(seatLayout);
  }, []);

  const handleSeatClick = (seatId: string) => {
    const seat = seats.find(s => s.id === seatId);
    if (!seat || seat.isBooked) return;

    setSeats(prev => prev.map(s => 
      s.id === seatId ? { ...s, isSelected: !s.isSelected } : s
    ));

    setSelectedSeats(prev => {
      const isSelected = prev.some(s => s.id === seatId);
      if (isSelected) {
        return prev.filter(s => s.id !== seatId);
      } else {
        return [...prev, { ...seat, isSelected: true }];
      }
    });
  };

  const calculateTotal = () => {
    return selectedSeats.reduce((total, seat) => {
      return total + showTime.prices[seat.type];
    }, 0);
  };

  const getSeatColor = (seat: Seat) => {
    if (seat.isBooked) return 'bg-gray-600 cursor-not-allowed';
    if (seat.isSelected) return 'bg-red-500 text-white';
    
    switch (seat.type) {
      case 'premium': return 'bg-yellow-500 hover:bg-yellow-600 cursor-pointer';
      case 'standard': return 'bg-blue-500 hover:bg-blue-600 cursor-pointer';
      case 'economy': return 'bg-green-500 hover:bg-green-600 cursor-pointer';
      default: return 'bg-gray-400';
    }
  };

  const groupedSeats = seats.reduce((acc, seat) => {
    if (!acc[seat.row]) acc[seat.row] = [];
    acc[seat.row].push(seat);
    return acc;
  }, {} as Record<string, Seat[]>);

  return (
    <div className="min-h-screen bg-gray-900 pb-20">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={onBack}
              className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back</span>
            </button>
            <div className="text-center">
              <h1 className="text-xl font-bold text-white">{movie.title}</h1>
              <p className="text-gray-400 text-sm">
                {showTime.theater} - {showTime.screen} | {showTime.time} | {showTime.date}
              </p>
            </div>
            <div className="w-20"></div>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Screen */}
        <div className="text-center mb-8">
          <div className="bg-gradient-to-r from-gray-700 via-gray-600 to-gray-700 h-2 rounded-full mb-2"></div>
          <p className="text-gray-400 text-sm">SCREEN</p>
        </div>

        {/* Seat Map */}
        <div className="bg-gray-800 rounded-xl p-6 mb-6">
          <div className="space-y-3">
            {Object.entries(groupedSeats).map(([row, rowSeats]) => (
              <div key={row} className="flex items-center justify-center space-x-2">
                <span className="text-gray-400 font-medium w-6 text-center">{row}</span>
                <div className="flex space-x-1">
                  {rowSeats.slice(0, 6).map((seat) => (
                    <button
                      key={seat.id}
                      onClick={() => handleSeatClick(seat.id)}
                      className={`w-8 h-8 rounded-t-lg text-xs font-medium transition-all ${getSeatColor(seat)}`}
                      disabled={seat.isBooked}
                    >
                      {seat.number}
                    </button>
                  ))}
                </div>
                <div className="w-4"></div>
                <div className="flex space-x-1">
                  {rowSeats.slice(6).map((seat) => (
                    <button
                      key={seat.id}
                      onClick={() => handleSeatClick(seat.id)}
                      className={`w-8 h-8 rounded-t-lg text-xs font-medium transition-all ${getSeatColor(seat)}`}
                      disabled={seat.isBooked}
                    >
                      {seat.number}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Legend */}
        <div className="bg-gray-800 rounded-xl p-6 mb-6">
          <h3 className="text-white font-medium mb-4">Seat Legend</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-green-500 rounded"></div>
              <span className="text-gray-300">Economy (${showTime.prices.economy})</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-blue-500 rounded"></div>
              <span className="text-gray-300">Standard (${showTime.prices.standard})</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-yellow-500 rounded"></div>
              <span className="text-gray-300">Premium (${showTime.prices.premium})</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-gray-600 rounded"></div>
              <span className="text-gray-300">Booked</span>
            </div>
          </div>
        </div>

        {/* Selection Summary */}
        {selectedSeats.length > 0 && (
          <div className="bg-gray-800 rounded-xl p-6">
            <h3 className="text-white font-medium mb-4">Selected Seats</h3>
            <div className="flex flex-wrap gap-2 mb-4">
              {selectedSeats.map((seat) => (
                <span
                  key={seat.id}
                  className="bg-red-600 text-white px-3 py-1 rounded-full text-sm"
                >
                  {seat.id} ({seat.type})
                </span>
              ))}
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 text-gray-300">
                <div className="flex items-center space-x-2">
                  <Users className="w-5 h-5" />
                  <span>{selectedSeats.length} seats</span>
                </div>
                <div className="flex items-center space-x-2">
                  <DollarSign className="w-5 h-5" />
                  <span className="text-xl font-bold text-white">${calculateTotal()}</span>
                </div>
              </div>
              <button
                onClick={() => onProceed(selectedSeats, calculateTotal())}
                className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-lg font-medium transition-colors"
              >
                Proceed to Payment
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SeatSelection;