import React from 'react';
import { CheckCircle, Calendar, Clock, MapPin, Users, Mail, Phone, Download, Home } from 'lucide-react';
import { BookingConfirmation as BookingConfirmationType } from '../types';

interface BookingConfirmationProps {
  booking: BookingConfirmationType;
  movie: any;
  showTime: any;
  onBackToHome: () => void;
}

const BookingConfirmation: React.FC<BookingConfirmationProps> = ({
  booking,
  movie,
  showTime,
  onBackToHome
}) => {
  const downloadTicket = () => {
    // In a real app, this would generate and download a PDF ticket
    alert('Ticket download feature would be implemented here');
  };

  return (
    <div className="min-h-screen bg-gray-900 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Success Header */}
        <div className="text-center mb-8">
          <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-4" />
          <h1 className="text-4xl font-bold text-white mb-2">Booking Confirmed!</h1>
          <p className="text-gray-400 text-lg">Your tickets have been booked successfully</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Ticket Details */}
          <div className="bg-gray-800 rounded-xl overflow-hidden">
            {/* Ticket Header */}
            <div className="bg-gradient-to-r from-red-600 to-red-700 p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold">E-Ticket</h2>
                <span className="bg-white text-red-600 px-3 py-1 rounded-lg font-bold text-sm">
                  #{booking.bookingId}
                </span>
              </div>
              <h3 className="text-xl font-bold">{movie.title}</h3>
              <p className="text-red-100">{movie.certificate} • {movie.duration} min</p>
            </div>

            {/* Ticket Body */}
            <div className="p-6">
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div>
                  <div className="flex items-center space-x-2 text-gray-400 mb-1">
                    <Calendar className="w-4 h-4" />
                    <span className="text-sm">Date</span>
                  </div>
                  <p className="text-white font-medium">
                    {new Date(showTime.date).toLocaleDateString('en-US', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>
                </div>

                <div>
                  <div className="flex items-center space-x-2 text-gray-400 mb-1">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">Time</span>
                  </div>
                  <p className="text-white font-medium">{showTime.time}</p>
                </div>
              </div>

              <div className="mb-6">
                <div className="flex items-center space-x-2 text-gray-400 mb-1">
                  <MapPin className="w-4 h-4" />
                  <span className="text-sm">Cinema</span>
                </div>
                <p className="text-white font-medium">{showTime.theater}</p>
                <p className="text-gray-400 text-sm">{showTime.screen}</p>
              </div>

              <div className="mb-6">
                <div className="flex items-center space-x-2 text-gray-400 mb-2">
                  <Users className="w-4 h-4" />
                  <span className="text-sm">Seats</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {booking.seats.map((seat) => (
                    <span
                      key={seat.id}
                      className="bg-red-600 text-white px-3 py-1 rounded-full text-sm font-medium"
                    >
                      {seat.id}
                    </span>
                  ))}
                </div>
              </div>

              <div className="border-t border-gray-700 pt-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Total Amount</span>
                  <span className="text-2xl font-bold text-white">${booking.totalAmount.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Barcode Placeholder */}
            <div className="bg-gray-700 p-4 border-t border-gray-600">
              <div className="bg-white h-16 rounded flex items-center justify-center">
                <div className="flex space-x-1">
                  {Array.from({ length: 20 }).map((_, i) => (
                    <div
                      key={i}
                      className="bg-black w-1 rounded"
                      style={{ height: `${Math.random() * 40 + 20}px` }}
                    />
                  ))}
                </div>
              </div>
              <p className="text-center text-gray-400 text-xs mt-2">
                {booking.bookingId}
              </p>
            </div>
          </div>

          {/* Customer & Booking Info */}
          <div className="space-y-6">
            <div className="bg-gray-800 rounded-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4">Customer Information</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Users className="w-5 h-5 text-gray-400" />
                  <span className="text-white">{booking.customerInfo.name}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="w-5 h-5 text-gray-400" />
                  <span className="text-white">{booking.customerInfo.email}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="w-5 h-5 text-gray-400" />
                  <span className="text-white">{booking.customerInfo.phone}</span>
                </div>
              </div>
            </div>

            <div className="bg-gray-800 rounded-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4">Booking Details</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Booking ID</span>
                  <span className="text-white font-mono">{booking.bookingId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Booking Date</span>
                  <span className="text-white">
                    {new Date(booking.bookingDate).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Number of Seats</span>
                  <span className="text-white">{booking.seats.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Payment Status</span>
                  <span className="text-green-400 font-medium">Confirmed</span>
                </div>
              </div>
            </div>

            <div className="bg-gray-800 rounded-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4">Important Notes</h3>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>• Please arrive 30 minutes before the show time</li>
                <li>• Carry a valid ID along with this e-ticket</li>
                <li>• No outside food or drinks allowed</li>
                <li>• Mobile phones must be on silent mode</li>
                <li>• Tickets once booked cannot be cancelled</li>
              </ul>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <button
                onClick={downloadTicket}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-medium py-3 rounded-lg transition-colors flex items-center justify-center space-x-2"
              >
                <Download className="w-5 h-5" />
                <span>Download Ticket</span>
              </button>
              
              <button
                onClick={onBackToHome}
                className="w-full bg-gray-700 hover:bg-gray-600 text-white font-medium py-3 rounded-lg transition-colors flex items-center justify-center space-x-2"
              >
                <Home className="w-5 h-5" />
                <span>Back to Home</span>
              </button>
            </div>
          </div>
        </div>

        {/* Success Message */}
        <div className="mt-8 text-center">
          <div className="bg-green-900/20 border border-green-700 rounded-xl p-6">
            <p className="text-green-400 font-medium">
              🎉 Congratulations! Your booking is confirmed. 
              A confirmation email has been sent to {booking.customerInfo.email}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingConfirmation;