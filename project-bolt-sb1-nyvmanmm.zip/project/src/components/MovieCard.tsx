import React from 'react';
import { Star, Clock, Calendar, Users } from 'lucide-react';
import { Movie } from '../types';

interface MovieCardProps {
  movie: Movie;
  onSelect: (movie: Movie) => void;
}

const MovieCard: React.FC<MovieCardProps> = ({ movie, onSelect }) => {
  return (
    <div 
      className="bg-gray-800 rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transform hover:scale-105 transition-all duration-300 cursor-pointer group"
      onClick={() => onSelect(movie)}
    >
      <div className="relative">
        <img
          src={movie.poster}
          alt={movie.title}
          className="w-full h-96 object-cover group-hover:opacity-90 transition-opacity"
        />
        <div className="absolute top-4 right-4 bg-black bg-opacity-70 text-white px-2 py-1 rounded-lg text-sm font-medium">
          {movie.certificate}
        </div>
        <div className="absolute bottom-4 left-4 bg-yellow-500 text-black px-2 py-1 rounded-lg flex items-center space-x-1">
          <Star className="w-4 h-4 fill-current" />
          <span className="font-bold text-sm">{movie.rating}</span>
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-bold text-white mb-2 line-clamp-1">{movie.title}</h3>
        
        <div className="flex items-center space-x-4 text-gray-400 text-sm mb-3">
          <div className="flex items-center space-x-1">
            <Clock className="w-4 h-4" />
            <span>{movie.duration} min</span>
          </div>
          <div className="flex items-center space-x-1">
            <Calendar className="w-4 h-4" />
            <span>{new Date(movie.releaseDate).getFullYear()}</span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {movie.genre.slice(0, 2).map((genre) => (
            <span
              key={genre}
              className="px-2 py-1 bg-gray-700 text-gray-300 text-xs rounded-full"
            >
              {genre}
            </span>
          ))}
        </div>
        
        <p className="text-gray-300 text-sm line-clamp-3 mb-4">
          {movie.description}
        </p>
        
        <button className="w-full bg-red-600 hover:bg-red-700 text-white font-medium py-3 rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2">
          <Users className="w-4 h-4" />
          <span>Book Tickets</span>
        </button>
      </div>
    </div>
  );
};

export default MovieCard;