import { Movie, ShowTime } from '../types';

export const movies: Movie[] = [
  {
    id: '1',
    title: 'Dune: Part Two',
    poster: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=400',
    backdrop: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=1200',
    genre: ['Sci-Fi', 'Adventure', 'Drama'],
    duration: 166,
    rating: 8.8,
    description: 'Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family.',
    director: 'Denis Villeneuve',
    cast: ['Timothée Chalamet', 'Zendaya', 'Rebecca Ferguson', 'Josh Brolin'],
    releaseDate: '2024-03-01',
    language: 'English',
    certificate: 'PG-13'
  },
  {
    id: '2',
    title: 'Oppenheimer',
    poster: 'https://images.pexels.com/photos/15286/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=400',
    backdrop: 'https://images.pexels.com/photos/15286/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1200',
    genre: ['Biography', 'Drama', 'History'],
    duration: 180,
    rating: 8.5,
    description: 'The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb.',
    director: 'Christopher Nolan',
    cast: ['Cillian Murphy', 'Emily Blunt', 'Matt Damon', 'Robert Downey Jr.'],
    releaseDate: '2023-07-21',
    language: 'English',
    certificate: 'R'
  },
  {
    id: '3',
    title: 'Spider-Man: Across the Spider-Verse',
    poster: 'https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg?auto=compress&cs=tinysrgb&w=400',
    backdrop: 'https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg?auto=compress&cs=tinysrgb&w=1200',
    genre: ['Animation', 'Action', 'Adventure'],
    duration: 140,
    rating: 8.7,
    description: 'Miles Morales catapults across the multiverse, where he encounters a team of Spider-People.',
    director: 'Joaquim Dos Santos',
    cast: ['Shameik Moore', 'Hailee Steinfeld', 'Brian Tyree Henry'],
    releaseDate: '2023-06-02',
    language: 'English',
    certificate: 'PG'
  },
  {
    id: '4',
    title: 'The Batman',
    poster: 'https://images.pexels.com/photos/163696/batman-lego-toy-blocks-163696.jpeg?auto=compress&cs=tinysrgb&w=400',
    backdrop: 'https://images.pexels.com/photos/163696/batman-lego-toy-blocks-163696.jpeg?auto=compress&cs=tinysrgb&w=1200',
    genre: ['Action', 'Crime', 'Drama'],
    duration: 176,
    rating: 7.8,
    description: 'When a sadistic serial killer begins murdering key political figures in Gotham, Batman is forced to investigate.',
    director: 'Matt Reeves',
    cast: ['Robert Pattinson', 'Zoë Kravitz', 'Jeffrey Wright', 'Colin Farrell'],
    releaseDate: '2022-03-04',
    language: 'English',
    certificate: 'PG-13'
  },
  {
    id: '5',
    title: 'Avatar: The Way of Water',
    poster: 'https://images.pexels.com/photos/1166643/pexels-photo-1166643.jpeg?auto=compress&cs=tinysrgb&w=400',
    backdrop: 'https://images.pexels.com/photos/1166643/pexels-photo-1166643.jpeg?auto=compress&cs=tinysrgb&w=1200',
    genre: ['Sci-Fi', 'Action', 'Adventure'],
    duration: 192,
    rating: 7.6,
    description: 'Jake Sully lives with his newfound family formed on the extrasolar moon Pandora.',
    director: 'James Cameron',
    cast: ['Sam Worthington', 'Zoe Saldana', 'Sigourney Weaver', 'Stephen Lang'],
    releaseDate: '2022-12-16',
    language: 'English',
    certificate: 'PG-13'
  },
  {
    id: '6',
    title: 'Top Gun: Maverick',
    poster: 'https://images.pexels.com/photos/1766838/pexels-photo-1766838.jpeg?auto=compress&cs=tinysrgb&w=400',
    backdrop: 'https://images.pexels.com/photos/1766838/pexels-photo-1766838.jpeg?auto=compress&cs=tinysrgb&w=1200',
    genre: ['Action', 'Drama'],
    duration: 130,
    rating: 8.3,
    description: 'After thirty years, Maverick is still pushing the envelope as a top naval aviator.',
    director: 'Joseph Kosinski',
    cast: ['Tom Cruise', 'Miles Teller', 'Jennifer Connelly', 'Jon Hamm'],
    releaseDate: '2022-05-27',
    language: 'English',
    certificate: 'PG-13'
  }
];

export const showTimes: ShowTime[] = [
  // Dune: Part Two
  {
    id: 'st1',
    movieId: '1',
    time: '10:00 AM',
    date: '2024-01-15',
    theater: 'CineMax Plaza',
    screen: 'Screen 1',
    availableSeats: 45,
    totalSeats: 120,
    prices: { premium: 25, standard: 18, economy: 12 }
  },
  {
    id: 'st2',
    movieId: '1',
    time: '2:30 PM',
    date: '2024-01-15',
    theater: 'CineMax Plaza',
    screen: 'Screen 2',
    availableSeats: 67,
    totalSeats: 150,
    prices: { premium: 25, standard: 18, economy: 12 }
  },
  {
    id: 'st3',
    movieId: '1',
    time: '7:00 PM',
    date: '2024-01-15',
    theater: 'Multiplex Center',
    screen: 'IMAX Screen',
    availableSeats: 23,
    totalSeats: 200,
    prices: { premium: 35, standard: 28, economy: 20 }
  },
  // Oppenheimer
  {
    id: 'st4',
    movieId: '2',
    time: '11:30 AM',
    date: '2024-01-15',
    theater: 'Royal Cinema',
    screen: 'Screen 3',
    availableSeats: 78,
    totalSeats: 100,
    prices: { premium: 22, standard: 16, economy: 10 }
  },
  {
    id: 'st5',
    movieId: '2',
    time: '4:15 PM',
    date: '2024-01-15',
    theater: 'CineMax Plaza',
    screen: 'Screen 1',
    availableSeats: 34,
    totalSeats: 120,
    prices: { premium: 25, standard: 18, economy: 12 }
  },
  {
    id: 'st6',
    movieId: '2',
    time: '8:45 PM',
    date: '2024-01-15',
    theater: 'Multiplex Center',
    screen: 'Screen 4',
    availableSeats: 56,
    totalSeats: 180,
    prices: { premium: 28, standard: 20, economy: 14 }
  }
];