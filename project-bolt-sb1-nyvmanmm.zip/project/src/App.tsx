import React, { useState } from 'react';
import Header from './components/Header';
import MovieCard from './components/MovieCard';
import MovieDetails from './components/MovieDetails';
import SeatSelection from './components/SeatSelection';
import BookingForm from './components/BookingForm';
import BookingConfirmation from './components/BookingConfirmation';
import { movies, showTimes } from './data/movies';
import { Movie, ShowTime, Seat, BookingConfirmation as BookingConfirmationType } from './types';

type AppState = 'home' | 'movieDetails' | 'seatSelection' | 'bookingForm' | 'confirmation';

function App() {
  const [currentView, setCurrentView] = useState<AppState>('home');
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [selectedShowTime, setSelectedShowTime] = useState<ShowTime | null>(null);
  const [selectedSeats, setSelectedSeats] = useState<Seat[]>([]);
  const [totalAmount, setTotalAmount] = useState(0);
  const [bookingConfirmation, setBookingConfirmation] = useState<BookingConfirmationType | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredMovies = movies.filter(movie =>
    movie.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    movie.genre.some(g => g.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleMovieSelect = (movie: Movie) => {
    setSelectedMovie(movie);
    setCurrentView('movieDetails');
  };

  const handleShowTimeSelect = (showTime: ShowTime) => {
    setSelectedShowTime(showTime);
    setCurrentView('seatSelection');
  };

  const handleSeatSelection = (seats: Seat[], amount: number) => {
    setSelectedSeats(seats);
    setTotalAmount(amount);
    setCurrentView('bookingForm');
  };

  const handleBookingConfirm = (customerInfo: { name: string; email: string; phone: string }) => {
    const confirmation: BookingConfirmationType = {
      bookingId: `BK${Date.now().toString().slice(-8)}`,
      bookingDate: new Date().toISOString(),
      movieId: selectedMovie!.id,
      showTimeId: selectedShowTime!.id,
      seats: selectedSeats,
      totalAmount,
      customerInfo
    };
    
    setBookingConfirmation(confirmation);
    setCurrentView('confirmation');
  };

  const resetToHome = () => {
    setCurrentView('home');
    setSelectedMovie(null);
    setSelectedShowTime(null);
    setSelectedSeats([]);
    setTotalAmount(0);
    setBookingConfirmation(null);
  };

  const renderCurrentView = () => {
    switch (currentView) {
      case 'home':
        return (
          <div className="min-h-screen bg-gray-900">
            <Header onSearch={setSearchQuery} searchQuery={searchQuery} />
            
            {/* Hero Section */}
            <div className="relative h-96 md:h-[500px] overflow-hidden">
              <img
                src="https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=1600"
                alt="Cinema"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent" />
              <div className="absolute inset-0 flex items-center">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
                  <div className="max-w-2xl">
                    <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
                      Book Your
                      <span className="text-red-500"> Movie </span>
                      Experience
                    </h1>
                    <p className="text-xl text-gray-300 mb-8">
                      Discover the latest blockbusters and reserve your perfect seats 
                      for an unforgettable cinema experience.
                    </p>
                    <div className="flex flex-wrap gap-4">
                      <button className="bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-8 rounded-lg transition-colors text-lg">
                        Explore Movies
                      </button>
                      <button className="border-2 border-white text-white hover:bg-white hover:text-gray-900 font-bold py-4 px-8 rounded-lg transition-colors text-lg">
                        View Offers
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Movies Section */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-3xl font-bold text-white">Now Showing</h2>
                <div className="text-gray-400">
                  {filteredMovies.length} movie{filteredMovies.length !== 1 ? 's' : ''} found
                </div>
              </div>
              
              {filteredMovies.length === 0 ? (
                <div className="text-center py-16">
                  <p className="text-gray-400 text-xl">No movies found matching your search.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                  {filteredMovies.map((movie) => (
                    <MovieCard
                      key={movie.id}
                      movie={movie}
                      onSelect={handleMovieSelect}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        );

      case 'movieDetails':
        return (
          <MovieDetails
            movie={selectedMovie!}
            showTimes={showTimes}
            onBack={resetToHome}
            onBookTickets={handleShowTimeSelect}
          />
        );

      case 'seatSelection':
        return (
          <SeatSelection
            movie={selectedMovie!}
            showTime={selectedShowTime!}
            onBack={() => setCurrentView('movieDetails')}
            onProceed={handleSeatSelection}
          />
        );

      case 'bookingForm':
        return (
          <BookingForm
            movie={selectedMovie!}
            showTime={selectedShowTime!}
            selectedSeats={selectedSeats}
            totalAmount={totalAmount}
            onBack={() => setCurrentView('seatSelection')}
            onConfirm={handleBookingConfirm}
          />
        );

      case 'confirmation':
        return (
          <BookingConfirmation
            booking={bookingConfirmation!}
            movie={selectedMovie}
            showTime={selectedShowTime}
            onBackToHome={resetToHome}
          />
        );

      default:
        return null;
    }
  };

  return renderCurrentView();
}

export default App;