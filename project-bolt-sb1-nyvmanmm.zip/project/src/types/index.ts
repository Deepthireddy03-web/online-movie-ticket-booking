export interface Movie {
  id: string;
  title: string;
  poster: string;
  backdrop: string;
  genre: string[];
  duration: number;
  rating: number;
  description: string;
  director: string;
  cast: string[];
  releaseDate: string;
  language: string;
  certificate: string;
}

export interface ShowTime {
  id: string;
  movieId: string;
  time: string;
  date: string;
  theater: string;
  screen: string;
  availableSeats: number;
  totalSeats: number;
  prices: {
    premium: number;
    standard: number;
    economy: number;
  };
}

export interface Seat {
  id: string;
  row: string;
  number: number;
  type: 'premium' | 'standard' | 'economy';
  isBooked: boolean;
  isSelected: boolean;
}

export interface BookingDetails {
  movieId: string;
  showTimeId: string;
  seats: Seat[];
  totalAmount: number;
  customerInfo: {
    name: string;
    email: string;
    phone: string;
  };
}

export interface BookingConfirmation extends BookingDetails {
  bookingId: string;
  bookingDate: string;
}